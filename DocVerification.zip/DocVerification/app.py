import os
import time
import blake3
import sqlite3
from web3 import Web3
from dotenv import load_dotenv
from flask import Flask, request, jsonify, render_template

load_dotenv()
WEB3_PROVIDER = os.getenv("WEB3_PROVIDER")
PRIVATE_KEY = os.getenv("PRIVATE_KEY")

web3 = Web3(Web3.HTTPProvider(WEB3_PROVIDER))

# Check if the connection is successful
if web3.is_connected():
    print("Connected to blockchain")
else:
    print("Failed to connect to blockchain")

# Define your wallet address and chain ID
from_address = "0x8883bFFa42A7f5B509D0929c6fFa041e46E18e2f"
chain_id = 12227332

app = Flask(__name__)

# SQLite database connection
conn = sqlite3.connect('document_verification.db')
c = conn.cursor()

# Create a table if it doesn't exist
c.execute('''
    CREATE TABLE IF NOT EXISTS documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        document_name TEXT,
        document_hash TEXT,
        txn_hash TEXT,
        timestamp TEXT
    )
''')
conn.commit()
conn.close()

# Function to add document hash to the database
def store_in_db(document_name, document_hash, txn_hash):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    conn = sqlite3.connect('document_verification.db')
    c = conn.cursor()
    c.execute('INSERT INTO documents (document_name, document_hash, txn_hash, timestamp) VALUES (?, ?, ?, ?)',
              (document_name, document_hash, txn_hash, timestamp))
    conn.commit()
    conn.close()

def get_hash_from_blockchain(txn_hash):
    try:
        txn = web3.eth.get_transaction(txn_hash)
        if not txn:
            return None

        stored_hash = txn.input.hex()  # Converts bytes to hex string
        
        return stored_hash
    except Exception as e:
        print(f"Error fetching hash from blockchain: {e}")
        return None

def verify_data(document_name, file_path):
    print(f"\nVerifying document: {document_name}")  # Debug log
    print(f"File path: {file_path}")  # Debug log
    
    try:
        # Calculate file hash
        if not os.path.exists(file_path):
            print("ERROR: File not found at path")  # Debug log
            return " ❌ Verification failed! File not found."
            
        # Calculate hash
        blake3_hasher = blake3.blake3()
        with open(file_path, "rb") as f:  
            for byte_block in iter(lambda: f.read(4096), b""):
                blake3_hasher.update(byte_block)
        calculated_hash = blake3_hasher.hexdigest()  # Get hex string for comparison
        print(f"Calculated hash: {calculated_hash}")  # Debug log
        
        # Connect to database to get the transaction hash
        conn = sqlite3.connect('document_verification.db')
        c = conn.cursor()
        
        # Search for the document's transaction hash using the hash instead of the filename
        c.execute('SELECT txn_hash FROM documents WHERE document_hash = ?', (calculated_hash,))

        result = c.fetchone()
        conn.close()
        
        if not result:
            print("No matching document found in DB")  # Debug log
            return " ❌ Verification failed! Document not found in records."
            
        txn_hash = result[0]
        print(f"Transaction hash from DB: {txn_hash}")  # Debug log
        
        # Fetch the stored hash from blockchain
        stored_hash = get_hash_from_blockchain(txn_hash)
        if not stored_hash:
            return " ❌ Verification failed! Could not fetch hash from blockchain."
        
        print(f"Stored hash from blockchain: {stored_hash}")  # Debug log
        
        # Compare hashes
        if calculated_hash == stored_hash:
            return " ✅ Verification successful! Document is authentic and matches blockchain record."
        else:
            return " ❌ Verification failed! Document does not match blockchain record."
        
    except Exception as e:
        print(f"Verification error: {str(e)}")  # Debug log
        return f" ❌ Verification error: {str(e)}"


@app.route('/')
def home():
    return render_template('index.html')

@app.route('/verify')
def verify():
    return render_template('verify.html')

@app.route('/upload_details')
def upload_details():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'image' not in request.files:
        return "No file part", 400
    image = request.files['image']
    if image.filename == '':
        return "No selected file", 400
    
    os.makedirs('uploads', exist_ok=True)
    save_path = os.path.join('uploads', image.filename)
    image.save(save_path)
    
    # Calculate file hash
    blake3_hasher = blake3.blake3()
    with open(save_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            blake3_hasher.update(byte_block)
    file_hash = blake3_hasher.hexdigest()

    
    # Prepare transaction
    account = web3.eth.account.from_key(PRIVATE_KEY)
    nonce = web3.eth.get_transaction_count(account.address)
    
    conn = sqlite3.connect('document_verification.db')
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM documents')
    result = c.fetchone()
    conn.close()
    
    length = result[0] if result else 0
    to_address = "0x0000000000000000000000000000000000000000"
    
    transaction = {
        'to': to_address,
        'value': web3.to_wei(0, 'ether'),
        'gas': 2000000,
        'gasPrice': web3.to_wei('50', 'gwei'),
        'nonce': nonce,
        'chainId': chain_id,
        'data': web3.to_bytes(hexstr=file_hash)
    }
    
    # Sign and send the transaction
    signed_txn = web3.eth.account.sign_transaction(transaction, PRIVATE_KEY)
    txn_hash = web3.eth.send_raw_transaction(signed_txn.raw_transaction)
    txn_hash_hex = web3.to_hex(txn_hash)
    
    # Store the document hash and transaction hash in the database
    store_in_db(image.filename, file_hash, txn_hash_hex)
    
    return jsonify({
        "status": "success",
        "document_name": image.filename,
        "document_hash": file_hash,
        "txn_hash": txn_hash_hex
    })

@app.route('/verify_document', methods=['POST'])
def verify_document():
    print("\n=== Verification Started ===")  # Debug log
    try:
        if 'image' not in request.files:
            print("No file part in request")  # Debug log
            return "No file part", 400
            
        image = request.files['image']
        print(f"Received file: {image.filename}")  # Debug log
        
        if image.filename == '':
            print("Empty filename")  # Debug log
            return "No selected file", 400
        
        # Create uploads directory if it doesn't exist
        os.makedirs('uploads', exist_ok=True)
        save_path = os.path.join('uploads', image.filename)
        print(f"Saving to: {save_path}")  # Debug log
        
        # Save the file
        image.save(save_path)
        print("File saved successfully")  # Debug log
        
        # Verify the document
        verification_result = verify_data(image.filename, save_path)
        print(f"Verification result: {verification_result}")  # Debug log
        
        # Clean up
        try:
            os.remove(save_path)
            print("Temporary file cleaned up")  # Debug log
        except Exception as e:
            print(f"Cleanup error: {str(e)}")  # Debug log
            
        return render_template('result.html',  
                            document_name=image.filename,
                            result=verification_result)
                            
    except Exception as e:
        print(f"ERROR in verify_document: {str(e)}")  # Debug log
        return f"Error processing verification: {str(e)}", 500

if __name__ == '__main__':
    app.run(debug=True)